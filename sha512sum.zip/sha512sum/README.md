# sha512sum

A simple app to get the sha512sum from a given text

## Why?

After chatting with a friend I realized it might me a good idea to hash my current passwords and use the hash as the actual password in online accounts. If an attacker
managed to get the hash of my password they wouldn't be able to guess a sha512 hash in their bruteforce attempt.

So yes, this app is extremly simple (hopefully this means there is no bugs)
